#!/bin/bash

cat README.md | grep \<\/summary\> | wc -l
